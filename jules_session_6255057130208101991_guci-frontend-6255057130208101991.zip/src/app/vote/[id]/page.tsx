'use client';

import { useState } from 'react';
import { CheckCircle2, ChevronLeft, ShieldCheck, AlertCircle, Loader2 } from 'lucide-react';
import Link from 'next/link';

const CANDIDATES = [
  {
    id: 'c1',
    name: 'Sarah Jenkins',
    position: 'President',
    department: 'Computer Science',
    photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop',
    manifesto: 'I aim to improve campus Wi-Fi and create more collaborative study spaces. My experience as a class rep has prepared me for this role.'
  },
  {
    id: 'c2',
    name: 'Michael Chen',
    position: 'President',
    department: 'Electrical Engineering',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
    manifesto: 'Transparency and accountability are my top priorities. I will ensure every student voice is heard in the union meetings.'
  },
  {
    id: 'c3',
    name: 'Elena Rodriguez',
    position: 'President',
    department: 'Business Administration',
    photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop',
    manifesto: 'Focusing on student mental health and extracurricular funding. Let\'s make campus life vibrant again.'
  }
];

export default function VotingBooth() {
  const [selectedCandidate, setSelectedCandidate] = useState<string | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = () => {
    setIsSubmitting(true);
    // Simulate anonymous vote submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-200 p-10 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 mb-4">Vote Cast Successfully!</h1>
          <p className="text-slate-600 mb-8 leading-relaxed">
            Your vote has been anonymized and recorded. Thank you for participating in the democratic process.
          </p>
          <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl mb-8 flex gap-3 text-left">
            <ShieldCheck className="w-6 h-6 text-blue-600 flex-shrink-0" />
            <p className="text-sm text-blue-800">
              <strong>Security Log:</strong> Your session token has been expired for this election to prevent double voting.
            </p>
          </div>
          <Link href="/student" className="block w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-slate-800 transition-all">
            Return to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <Link href="/student" className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <ChevronLeft className="w-6 h-6 text-slate-600" />
          </Link>
          <div>
            <h1 className="font-bold text-slate-900">Student Union President 2025</h1>
            <p className="text-xs text-slate-500 font-medium">Voting Booth • One Choice Allowed</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-full text-xs font-bold text-slate-600">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          SECURE SESSION
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full px-6 py-10">
        <div className="mb-10">
          <h2 className="text-2xl font-extrabold text-slate-900 mb-2">Select Your Candidate</h2>
          <p className="text-slate-500">Read manifestos carefully before making your choice.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {CANDIDATES.map((candidate) => (
            <div 
              key={candidate.id}
              onClick={() => !showConfirm && setSelectedCandidate(candidate.id)}
              className={`relative bg-white rounded-2xl border-2 transition-all cursor-pointer overflow-hidden flex flex-col ${
                selectedCandidate === candidate.id 
                  ? 'border-blue-600 shadow-md ring-4 ring-blue-50' 
                  : 'border-slate-100 hover:border-slate-300 shadow-sm'
              }`}
            >
              <div className="aspect-square bg-slate-100 relative">
                {/* Fallback for images */}
                <div className="absolute inset-0 flex items-center justify-center text-slate-300">
                  <span className="text-4xl font-bold">{candidate.name[0]}</span>
                </div>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img 
                  src={candidate.photo} 
                  alt={candidate.name}
                  className="absolute inset-0 w-full h-full object-cover"
                />
                {selectedCandidate === candidate.id && (
                  <div className="absolute top-4 right-4 bg-blue-600 text-white p-1.5 rounded-full">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                )}
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="mb-4">
                  <h3 className="font-bold text-slate-900 text-lg">{candidate.name}</h3>
                  <p className="text-blue-600 text-sm font-medium">{candidate.department}</p>
                </div>
                <p className="text-slate-600 text-sm leading-relaxed mb-6 line-clamp-3">
                  &quot;{candidate.manifesto}&quot;
                </p>
                <button 
                  className={`mt-auto w-full py-2.5 rounded-xl font-bold text-sm transition-all ${
                    selectedCandidate === candidate.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {selectedCandidate === candidate.id ? 'Selected' : 'Select Candidate'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Action Bar */}
        <div className="mt-12 flex justify-center">
          <button
            disabled={!selectedCandidate}
            onClick={() => setShowConfirm(true)}
            className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all shadow-xl disabled:opacity-30 disabled:cursor-not-allowed active:scale-95"
          >
            Review & Submit Vote
          </button>
        </div>
      </main>

      {/* Confirmation Modal */}
      {showConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" onClick={() => !isSubmitting && setShowConfirm(false)}></div>
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg relative z-10 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-8 border-b border-slate-100 flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900">Confirm Your Vote</h3>
                <p className="text-sm text-slate-500">This action cannot be undone.</p>
              </div>
            </div>

            <div className="p-8">
              <p className="text-slate-600 mb-6">You are about to cast your vote for:</p>
              <div className="bg-slate-50 p-4 rounded-2xl flex items-center gap-4 border border-slate-100 mb-8">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img 
                  src={CANDIDATES.find(c => c.id === selectedCandidate)?.photo} 
                  alt="Selected"
                  className="w-16 h-16 rounded-xl object-cover"
                />
                <div>
                  <h4 className="font-bold text-slate-900 text-lg">
                    {CANDIDATES.find(c => c.id === selectedCandidate)?.name}
                  </h4>
                  <p className="text-blue-600 text-sm font-medium">Candidate for President</p>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <button
                  disabled={isSubmitting}
                  onClick={handleSubmit}
                  className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all flex items-center justify-center gap-3"
                >
                  {isSubmitting ? <Loader2 className="w-6 h-6 animate-spin" /> : "Confirm and Submit"}
                </button>
                <button
                  disabled={isSubmitting}
                  onClick={() => setShowConfirm(false)}
                  className="w-full text-slate-500 py-2 font-medium hover:text-slate-800 transition-all"
                >
                  Go Back
                </button>
              </div>
            </div>
            
            <div className="bg-slate-50 p-4 text-center">
              <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">
                Anonymous & Secure End-to-End Encryption
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import Link from 'next/link';
import { Vote, Shield, BarChart3, Users } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <Vote className="w-8 h-8 text-blue-600" />
          <span className="text-2xl font-bold text-slate-800 tracking-tight">GUCI</span>
        </div>
        <div className="flex gap-4">
          <Link 
            href="/login" 
            className="px-4 py-2 text-slate-600 font-medium hover:text-blue-600 transition-colors"
          >
            Log In
          </Link>
          <Link 
            href="/login" 
            className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors shadow-sm"
          >
            Start Voting
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 max-w-6xl mx-auto px-6 py-16 flex flex-col items-center text-center">
        <div className="mb-6 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-sm font-medium">
          <Shield className="w-4 h-4" />
          Secure & Transparent Student Voting
        </div>
        <h1 className="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 leading-tight">
          Next-Generation E-Voting <br />
          <span className="text-blue-600">for Modern Students</span>
        </h1>
        <p className="text-xl text-slate-600 mb-10 max-w-2xl leading-relaxed">
          GUCI provides a secure, anonymous, and easy-to-use platform for student elections. 
          Powered by biometric security and real-time analytics.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 mb-20">
          <Link 
            href="/login" 
            className="px-8 py-4 bg-blue-600 text-white rounded-xl font-bold text-lg hover:bg-blue-700 transition-all shadow-lg hover:shadow-xl active:scale-95"
          >
            Student Access
          </Link>
          <Link 
            href="/login" 
            className="px-8 py-4 bg-white text-slate-800 border-2 border-slate-200 rounded-xl font-bold text-lg hover:border-blue-200 hover:bg-slate-50 transition-all active:scale-95"
          >
            Admin Portal
          </Link>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 w-full">
          <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-6 mx-auto">
              <Shield className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-3">Secure & Anonymous</h3>
            <p className="text-slate-600">
              Advanced hashing ensures your vote remains private while preventing double-voting.
            </p>
          </div>
          <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-6 mx-auto">
              <BarChart3 className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-3">Live Analytics</h3>
            <p className="text-slate-600">
              Real-time turnout tracking and beautiful result visualizations post-election.
            </p>
          </div>
          <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-6 mx-auto">
              <Users className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-3">Biometric Auth</h3>
            <p className="text-slate-600">
              Integrated face recognition option to ensure only authorized students can vote.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-10 mt-auto">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <Vote className="w-6 h-6 text-slate-400" />
            <span className="font-bold text-slate-400">GUCI E-Voting</span>
          </div>
          <p className="text-slate-500 text-sm">
            © 2025 GUCI E-Voting System. Built for students, by students.
          </p>
          <div className="flex gap-6 text-sm font-medium text-slate-500">
            <a href="#" className="hover:text-blue-600">Privacy Policy</a>
            <a href="#" className="hover:text-blue-600">Terms of Service</a>
            <a href="#" className="hover:text-blue-600">Contact Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

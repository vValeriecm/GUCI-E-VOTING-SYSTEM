'use client';

import { useState, useMemo } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { 
  ChevronLeft, 
  Download, 
  Award,
  CheckCircle2,
  Shield
} from 'lucide-react';
import Link from 'next/link';
import jsPDF from 'jspdf';

const DATA = [
  { name: 'Sarah Jenkins', votes: 560, color: '#2563eb' },
  { name: 'Michael Chen', votes: 420, color: '#7c3aed' },
  { name: 'Elena Rodriguez', votes: 260, color: '#db2777' },
];

const TURNOUT_DATA = [
  { name: 'Voted', value: 1240, color: '#10b981' },
  { name: 'Not Voted', value: 1560, color: '#e2e8f0' },
];

export default function ElectionResults() {
  const [isExporting, setIsExporting] = useState(false);

  const totalVotes = useMemo(() => DATA.reduce((sum, item) => sum + item.votes, 0), []);
  const winner = useMemo(() => [...DATA].sort((a, b) => b.votes - a.votes)[0], []);

  const handleExportPDF = () => {
    setIsExporting(true);
    const doc = new jsPDF();
    
    doc.setFontSize(22);
    doc.text('GUCI E-Voting System - Election Results', 20, 20);
    
    doc.setFontSize(16);
    doc.text(`Election: Student Union President 2025`, 20, 35);
    
    doc.setFontSize(12);
    doc.text(`Total Votes Cast: ${totalVotes}`, 20, 50);
    doc.text(`Winner: ${winner.name} (${winner.votes} votes)`, 20, 60);
    
    doc.text('Detailed Results:', 20, 80);
    DATA.forEach((item, index) => {
      doc.text(`${item.name}: ${item.votes} votes (${((item.votes/totalVotes)*100).toFixed(1)}%)`, 30, 90 + (index * 10));
    });
    
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 20, 280);
    doc.text('Digital Signature Verified - GUCI Audit System', 20, 285);
    
    doc.save('election-results.pdf');
    setIsExporting(false);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-8 py-4 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/admin" className="p-2 hover:bg-slate-100 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6 text-slate-600" />
            </Link>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Election Results</h1>
              <p className="text-xs text-slate-500 font-medium">Student Union President 2025 • Official Tally</p>
            </div>
          </div>
          <button 
            onClick={handleExportPDF}
            disabled={isExporting}
            className="bg-white border border-slate-200 text-slate-700 px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            {isExporting ? 'Generating...' : 'Export PDF'}
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-8">
        {/* Banner */}
        <div className="bg-blue-600 rounded-3xl p-8 text-white mb-8 flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-4">
              <Award className="w-6 h-6 text-amber-400" />
              <span className="font-bold tracking-widest uppercase text-xs text-blue-100">Election Winner</span>
            </div>
            <h2 className="text-4xl font-black mb-2">{winner.name}</h2>
            <p className="text-blue-100 text-lg">
              Elected with <span className="font-bold text-white">{winner.votes} votes</span> ({((winner.votes/totalVotes)*100).toFixed(1)}%)
            </p>
          </div>
          <div className="relative z-10 flex gap-4">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 text-center">
              <p className="text-blue-100 text-xs font-bold uppercase mb-1">Total Ballots</p>
              <p className="text-2xl font-bold">{totalVotes}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 text-center">
              <p className="text-blue-100 text-xs font-bold uppercase mb-1">Turnout</p>
              <p className="text-2xl font-bold">44.3%</p>
            </div>
          </div>
          <Shield className="absolute -right-10 -bottom-10 w-64 h-64 text-white/5 rotate-12" />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Chart */}
          <div className="lg:col-span-2 bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-lg font-bold text-slate-800">Vote Distribution</h3>
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                Verified Results
              </div>
            </div>
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={DATA} layout="vertical" margin={{ left: 40, right: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f1f5f9" />
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 12, fontWeight: 600, fill: '#64748b' }}
                  />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc' }}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="votes" radius={[0, 8, 8, 0]} barSize={40}>
                    {DATA.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Sidebar Stats */}
          <div className="space-y-8">
            {/* Turnout Pie */}
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
              <h3 className="text-lg font-bold text-slate-800 mb-6">Participation</h3>
              <div className="h-[200px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={TURNOUT_DATA}
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {TURNOUT_DATA.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-black text-slate-800">44%</span>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Turnout</span>
                </div>
              </div>
              <div className="mt-6 space-y-3">
                {TURNOUT_DATA.map((item) => (
                  <div key={item.name} className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                      <span className="text-slate-600">{item.name}</span>
                    </div>
                    <span className="font-bold text-slate-800">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Audit Info */}
            <div className="bg-slate-900 rounded-3xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <Shield className="w-5 h-5 text-blue-400" />
                <h3 className="font-bold">Security Audit</h3>
              </div>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5"></div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    All votes were cast via SSL-encrypted channels and verified with student tokens.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5"></div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Zero anomalies detected in voting patterns. Double-voting protection was active.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

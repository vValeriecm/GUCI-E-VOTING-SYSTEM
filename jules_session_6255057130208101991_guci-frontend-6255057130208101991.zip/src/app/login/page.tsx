'use client';

import { useState, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Webcam from 'react-webcam';
import { Shield, User, Lock, Camera, ArrowRight, Loader2, AlertCircle } from 'lucide-react';

export default function LoginPage() {
  const [useFaceId, setUseFaceId] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    studentId: '',
    password: '',
  });
  
  const webcamRef = useRef<Webcam>(null);
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Simulate API call
    setTimeout(() => {
      if (formData.studentId === 'admin') {
        router.push('/admin');
      } else if (formData.studentId.length > 3) {
        router.push('/student');
      } else {
        setError('Invalid credentials. Please try again.');
        setIsLoading(false);
      }
    }, 1500);
  };

  const handleFaceIdCapture = useCallback(() => {
    setIsLoading(true);
    // Simulate face recognition processing
    setTimeout(() => {
      router.push('/student');
    }, 2000);
  }, [router]);

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="bg-blue-600 p-8 text-center text-white">
          <Shield className="w-12 h-12 mx-auto mb-4" />
          <h1 className="text-2xl font-bold">Welcome to GUCI</h1>
          <p className="text-blue-100 mt-2">Secure Student E-Voting System</p>
        </div>

        <div className="p-8">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-lg flex items-center gap-3 text-red-700 text-sm">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              {error}
            </div>
          )}

          {!useFaceId ? (
            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Student ID or Email</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="text"
                    required
                    className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                    placeholder="e.g. 202100123"
                    value={formData.studentId}
                    onChange={(e) => setFormData({...formData, studentId: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="password"
                    required
                    className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Sign In"}
                {!isLoading && <ArrowRight className="w-5 h-5" />}
              </button>

              <div className="relative py-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-slate-500 font-medium">Or continue with</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setUseFaceId(true)}
                className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
              >
                <Camera className="w-5 h-5" />
                Face Recognition
              </button>
            </form>
          ) : (
            <div className="space-y-6 text-center">
              <div className="relative rounded-2xl overflow-hidden border-2 border-blue-500 bg-black aspect-video flex items-center justify-center">
                <Webcam
                  audio={false}
                  ref={webcamRef}
                  screenshotFormat="image/jpeg"
                  className="w-full h-full object-cover"
                />
                {isLoading && (
                  <div className="absolute inset-0 bg-blue-600/20 backdrop-blur-sm flex flex-col items-center justify-center text-white">
                    <Loader2 className="w-12 h-12 animate-spin mb-4" />
                    <p className="font-bold">Analyzing Face...</p>
                  </div>
                )}
              </div>
              
              <p className="text-slate-600 text-sm italic">
                Position your face in the center of the frame
              </p>

              <div className="flex flex-col gap-3">
                <button
                  onClick={handleFaceIdCapture}
                  disabled={isLoading}
                  className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all disabled:opacity-50"
                >
                  Confirm Identity
                </button>
                <button
                  onClick={() => setUseFaceId(false)}
                  disabled={isLoading}
                  className="w-full text-slate-500 py-2 text-sm font-medium hover:text-slate-800 transition-all"
                >
                  Back to Password Login
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

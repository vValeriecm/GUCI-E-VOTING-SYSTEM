'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { 
  ChevronLeft, 
  Calendar, 
  UserPlus, 
  X, 
  Image as ImageIcon,
  Save,
  Loader2
} from 'lucide-react';
import Link from 'next/link';

export default function CreateElection() {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const [candidates, setCandidates] = useState([
    { id: 1, name: '', department: '', manifesto: '' }
  ]);

  const addCandidate = () => {
    setCandidates([...candidates, { id: Date.now(), name: '', department: '', manifesto: '' }]);
  };

  const removeCandidate = (id: number) => {
    setCandidates(candidates.filter(c => c.id !== id));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      router.push('/admin');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-8 py-4 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/admin" className="p-2 hover:bg-slate-100 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6 text-slate-600" />
            </Link>
            <h1 className="text-xl font-bold text-slate-900">Create New Election</h1>
          </div>
          <button 
            onClick={handleSave}
            disabled={isLoading}
            className="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-700 transition-all shadow-md disabled:opacity-50"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Publish Election
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-8">
        <form onSubmit={handleSave} className="space-y-8">
          {/* General Info */}
          <section className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
            <h2 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
              <span className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center text-sm">1</span>
              General Information
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Election Title</label>
                <input 
                  type="text" 
                  placeholder="e.g. Student Union President 2025"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  required
                />
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Start Date & Time</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input 
                      type="datetime-local" 
                      className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">End Date & Time</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input 
                      type="datetime-local" 
                      className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                      required
                    />
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Eligibility Rules</label>
                <select className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all">
                  <option>All Students</option>
                  <option>Faculty of Engineering Only</option>
                  <option>Postgraduate Students Only</option>
                  <option>Undergraduate - Year 1 Only</option>
                </select>
              </div>
            </div>
          </section>

          {/* Candidates */}
          <section className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <span className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center text-sm">2</span>
                Candidates
              </h2>
              <button 
                type="button"
                onClick={addCandidate}
                className="text-blue-600 text-sm font-bold flex items-center gap-1 hover:bg-blue-50 px-3 py-1.5 rounded-lg transition-all"
              >
                <UserPlus className="w-4 h-4" />
                Add Candidate
              </button>
            </div>

            <div className="space-y-8">
              {candidates.map((candidate) => (
                <div key={candidate.id} className="p-6 bg-slate-50 rounded-2xl border border-slate-100 relative group">
                  {candidates.length > 1 && (
                    <button 
                      type="button"
                      onClick={() => removeCandidate(candidate.id)}
                      className="absolute -top-2 -right-2 bg-white text-slate-400 hover:text-red-500 p-1.5 rounded-full shadow-sm border border-slate-100 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                  <div className="grid md:grid-cols-4 gap-6">
                    <div className="md:col-span-1">
                      <div className="aspect-square bg-white border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center text-slate-400 hover:border-blue-300 hover:text-blue-500 cursor-pointer transition-all">
                        <ImageIcon className="w-8 h-8 mb-2" />
                        <span className="text-[10px] font-bold uppercase tracking-wider">Upload Photo</span>
                      </div>
                    </div>
                    <div className="md:col-span-3 space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <input 
                          type="text" 
                          placeholder="Candidate Name"
                          className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          required
                        />
                        <input 
                          type="text" 
                          placeholder="Department"
                          className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          required
                        />
                      </div>
                      <textarea 
                        placeholder="Manifesto - What do they stand for?"
                        className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm min-h-[100px]"
                        required
                      ></textarea>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="bg-blue-900 p-6 rounded-2xl text-white flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                <Loader2 className="w-6 h-6 text-blue-300" />
              </div>
              <div>
                <p className="font-bold">Ready to Launch?</p>
                <p className="text-blue-200 text-sm text-balance">Ensure all details are correct. Once published, candidates cannot be changed during an active election.</p>
              </div>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
}

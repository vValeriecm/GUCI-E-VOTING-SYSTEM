import Link from 'next/link';
import { 
  ChevronLeft, 
  Shield, 
  Search, 
  Filter, 
  FileText,
  Clock,
  User,
  Info
} from 'lucide-react';

const AUDIT_LOGS = [
  {
    id: 'L1',
    action: 'VOTE_CAST',
    user: 'Student #***456',
    details: 'Ballot submitted for Student Union President 2025',
    timestamp: '2025-06-01 14:22:10',
    severity: 'info'
  },
  {
    id: 'L2',
    action: 'ADMIN_LOGIN',
    user: 'Admin (System)',
    details: 'Successful login from IP 192.168.1.45',
    timestamp: '2025-06-01 13:05:22',
    severity: 'info'
  },
  {
    id: 'L3',
    action: 'ELECTION_CREATED',
    user: 'Admin (System)',
    details: 'New election "Engineering Rep" created',
    timestamp: '2025-06-01 11:45:00',
    severity: 'info'
  },
  {
    id: 'L4',
    action: 'UNAUTHORIZED_ACCESS_ATTEMPT',
    user: 'Unknown',
    details: 'Failed login attempt for Student ID: 99999999',
    timestamp: '2025-06-01 10:15:30',
    severity: 'warning'
  },
  {
    id: 'L5',
    action: 'VOTE_CAST',
    user: 'Student #***892',
    details: 'Ballot submitted for Student Union President 2025',
    timestamp: '2025-06-01 09:40:12',
    severity: 'info'
  }
];

export default function AuditLogs() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 px-8 py-4 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/admin" className="p-2 hover:bg-slate-100 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6 text-slate-600" />
            </Link>
            <div className="flex items-center gap-3">
              <Shield className="w-6 h-6 text-blue-600" />
              <h1 className="text-xl font-bold text-slate-900">Security & Audit Logs</h1>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="p-2 text-slate-400 hover:text-slate-600">
              <Search className="w-5 h-5" />
            </button>
            <button className="p-2 text-slate-400 hover:text-slate-600">
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto w-full p-8">
        <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 mb-8 flex gap-4">
          <Info className="w-6 h-6 text-blue-600 flex-shrink-0" />
          <div className="text-sm text-blue-800">
            <p className="font-bold mb-1">Privacy Compliance</p>
            <p>These logs track system activity and voting timestamps to ensure integrity. Voter identities are partially masked and never linked to specific ballot choices in this view.</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <th className="px-6 py-4">Action</th>
                  <th className="px-6 py-4">User</th>
                  <th className="px-6 py-4">Details</th>
                  <th className="px-6 py-4">Timestamp</th>
                  <th className="px-6 py-4">Severity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {AUDIT_LOGS.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className={`p-1.5 rounded-lg ${
                          log.action === 'VOTE_CAST' ? 'bg-green-50 text-green-600' : 'bg-blue-50 text-blue-600'
                        }`}>
                          <FileText className="w-4 h-4" />
                        </div>
                        <span className="font-bold text-sm text-slate-700">{log.action}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      <div className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5" />
                        {log.user}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500 max-w-xs">
                      {log.details}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5" />
                        {log.timestamp}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                        log.severity === 'warning' 
                          ? 'bg-amber-100 text-amber-700' 
                          : 'bg-slate-100 text-slate-500'
                      }`}>
                        {log.severity}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-6 border-t border-slate-100 bg-slate-50/30 flex justify-center">
            <button className="text-blue-600 font-bold text-sm hover:underline">Load older logs</button>
          </div>
        </div>
      </main>
    </div>
  );
}

import Link from 'next/link';
import { 
  Plus, 
  Settings, 
  Users, 
  FileText, 
  Activity, 
  BarChart3, 
  Vote, 
  LogOut,
  ChevronRight,
  TrendingUp,
  Clock
} from 'lucide-react';

const ELECTIONS = [
  {
    id: 'e1',
    title: 'Student Union President 2025',
    status: 'Active',
    turnout: '45%',
    voters: 1240,
    totalEligible: 2800,
    end: '3 days left'
  },
  {
    id: 'e2',
    title: 'Faculty of Engineering Representative',
    status: 'Active',
    turnout: '62%',
    voters: 840,
    totalEligible: 1350,
    end: '1 day left'
  },
  {
    id: 'p1',
    title: 'Sports Committee Elections 2024',
    status: 'Completed',
    turnout: '58%',
    voters: 1560,
    totalEligible: 2700,
    end: 'Ended Dec 2024'
  }
];

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Admin Sidebar */}
      <aside className="w-64 bg-slate-900 text-slate-300 hidden md:flex flex-col">
        <div className="p-6 flex items-center gap-2 border-b border-slate-800">
          <Vote className="w-8 h-8 text-blue-500" />
          <span className="text-2xl font-bold text-white tracking-tight">GUCI</span>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          <p className="px-4 py-2 text-xs font-bold text-slate-500 uppercase tracking-widest">Main</p>
          <Link href="/admin" className="flex items-center gap-3 px-4 py-3 bg-blue-600 text-white rounded-xl font-medium">
            <Activity className="w-5 h-5" />
            Dashboard
          </Link>
          <Link href="/admin/elections" className="flex items-center gap-3 px-4 py-3 hover:bg-slate-800 rounded-xl font-medium transition-colors">
            <Vote className="w-5 h-5" />
            Elections
          </Link>
          <Link href="/admin/users" className="flex items-center gap-3 px-4 py-3 hover:bg-slate-800 rounded-xl font-medium transition-colors">
            <Users className="w-5 h-5" />
            Students
          </Link>
          
          <p className="px-4 py-2 mt-6 text-xs font-bold text-slate-500 uppercase tracking-widest">Logs & Analytics</p>
          <Link href="/admin/audit" className="flex items-center gap-3 px-4 py-3 hover:bg-slate-800 rounded-xl font-medium transition-colors">
            <FileText className="w-5 h-5" />
            Audit Logs
          </Link>
          <Link href="/admin/analytics" className="flex items-center gap-3 px-4 py-3 hover:bg-slate-800 rounded-xl font-medium transition-colors">
            <BarChart3 className="w-5 h-5" />
            Analytics
          </Link>
        </nav>
        <div className="p-4 border-t border-slate-800">
          <Link href="/login" className="flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-white transition-colors">
            <LogOut className="w-5 h-5" />
            Sign Out
          </Link>
        </div>
      </aside>

      {/* Admin Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="bg-white border-b border-slate-200 px-8 py-4 flex justify-between items-center sticky top-0 z-10">
          <h1 className="text-xl font-bold text-slate-800">Admin Control Center</h1>
          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-400 hover:text-slate-600">
              <Settings className="w-5 h-5" />
            </button>
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-xs border border-blue-200">
              AD
            </div>
          </div>
        </header>

        <div className="p-8 max-w-6xl">
          <div className="flex justify-between items-end mb-8">
            <div>
              <h2 className="text-3xl font-extrabold text-slate-900">Election Overview</h2>
              <p className="text-slate-500">Manage ongoing elections and monitor results in real-time.</p>
            </div>
            <Link 
              href="/admin/elections/create" 
              className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
            >
              <Plus className="w-5 h-5" />
              New Election
            </Link>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex justify-between items-start mb-4">
                <div className="p-2 bg-blue-50 rounded-lg text-blue-600"><Vote className="w-5 h-5" /></div>
                <span className="text-green-500 text-xs font-bold flex items-center gap-1"><TrendingUp className="w-3 h-3"/> +12%</span>
              </div>
              <p className="text-slate-500 text-sm font-medium">Total Votes</p>
              <h3 className="text-2xl font-bold text-slate-900">4,281</h3>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex justify-between items-start mb-4">
                <div className="p-2 bg-purple-50 rounded-lg text-purple-600"><Users className="w-5 h-5" /></div>
                <span className="text-slate-400 text-xs font-bold">Stable</span>
              </div>
              <p className="text-slate-500 text-sm font-medium">Eligible Students</p>
              <h3 className="text-2xl font-bold text-slate-900">8,450</h3>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex justify-between items-start mb-4">
                <div className="p-2 bg-green-50 rounded-lg text-green-600"><BarChart3 className="w-5 h-5" /></div>
                <span className="text-green-500 text-xs font-bold">+5.2%</span>
              </div>
              <p className="text-slate-500 text-sm font-medium">Avg. Turnout</p>
              <h3 className="text-2xl font-bold text-slate-900">51.4%</h3>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex justify-between items-start mb-4">
                <div className="p-2 bg-amber-50 rounded-lg text-amber-600"><Clock className="w-5 h-5" /></div>
              </div>
              <p className="text-slate-500 text-sm font-medium">Active Elections</p>
              <h3 className="text-2xl font-bold text-slate-900">2</h3>
            </div>
          </div>

          {/* Elections List */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
              <h3 className="font-bold text-slate-800">Recent Elections</h3>
              <button className="text-blue-600 text-sm font-bold hover:underline">View All</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-slate-100 text-xs font-bold text-slate-400 uppercase tracking-widest">
                    <th className="px-6 py-4">Election Name</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Turnout</th>
                    <th className="px-6 py-4">Voters</th>
                    <th className="px-6 py-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {ELECTIONS.map((election) => (
                    <tr key={election.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-6 py-4">
                        <p className="font-bold text-slate-800">{election.title}</p>
                        <p className="text-xs text-slate-400">{election.end}</p>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          election.status === 'Active' 
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-slate-100 text-slate-500'
                        }`}>
                          {election.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                            <div 
                              className="bg-blue-500 h-full rounded-full" 
                              style={{ width: election.turnout }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-slate-600">{election.turnout}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {election.voters} / {election.totalEligible}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Link 
                          href={`/results/${election.id}`}
                          className="p-2 text-slate-400 hover:text-blue-600 inline-flex items-center gap-1 text-sm font-bold"
                        >
                          Results
                          <ChevronRight className="w-4 h-4" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

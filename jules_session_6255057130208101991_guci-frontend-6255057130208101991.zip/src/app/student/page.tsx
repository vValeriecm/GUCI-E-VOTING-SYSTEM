import Link from 'next/link';
import { Vote, Calendar, Clock, CheckCircle2, AlertCircle, ChevronRight, LayoutDashboard, LogOut } from 'lucide-react';

const ACTIVE_ELECTIONS = [
  {
    id: 'e1',
    title: 'Student Union President 2025',
    endDate: '2025-06-15T18:00:00',
    voted: false,
    positions: 1,
    candidates: 4
  },
  {
    id: 'e2',
    title: 'Faculty of Engineering Representative',
    endDate: '2025-06-10T12:00:00',
    voted: true,
    positions: 1,
    candidates: 3
  }
];

const PAST_ELECTIONS = [
  {
    id: 'p1',
    title: 'Sports Committee Elections 2024',
    date: 'Dec 2024',
    winner: 'John Doe'
  }
];

export default function StudentDashboard() {
  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 hidden md:flex flex-col">
        <div className="p-6 border-b border-slate-100 flex items-center gap-2">
          <Vote className="w-6 h-6 text-blue-600" />
          <span className="font-bold text-xl text-slate-800">GUCI</span>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <Link href="/student" className="flex items-center gap-3 px-4 py-3 bg-blue-50 text-blue-700 rounded-xl font-medium">
            <LayoutDashboard className="w-5 h-5" />
            Dashboard
          </Link>
          <Link href="/student/profile" className="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-50 rounded-xl font-medium transition-colors">
            <Calendar className="w-5 h-5" />
            My Votes
          </Link>
        </nav>
        <div className="p-4 mt-auto border-t border-slate-100">
          <Link href="/login" className="flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-xl font-medium transition-colors">
            <LogOut className="w-5 h-5" />
            Logout
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-10 max-w-5xl">
        <header className="flex justify-between items-end mb-10">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-900">Student Dashboard</h1>
            <p className="text-slate-500 mt-1">Welcome back, Student #202100456</p>
          </div>
          <div className="hidden sm:block text-right">
            <p className="text-sm font-medium text-slate-400 uppercase tracking-wider">Current Session</p>
            <p className="text-slate-900 font-bold">Academic Year 2024/25</p>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <p className="text-slate-500 text-sm font-medium mb-1">Open Elections</p>
            <h3 className="text-3xl font-bold text-slate-900">2</h3>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <p className="text-slate-500 text-sm font-medium mb-1">Votes Cast</p>
            <h3 className="text-3xl font-bold text-blue-600">1</h3>
          </div>
        </div>

        {/* Active Elections */}
        <section className="mb-12">
          <div className="flex items-center gap-2 mb-6">
            <Clock className="w-5 h-5 text-blue-600" />
            <h2 className="text-xl font-bold text-slate-800">Active Elections</h2>
          </div>
          
          <div className="space-y-4">
            {ACTIVE_ELECTIONS.map((election) => (
              <div key={election.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:border-blue-200 transition-colors">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 mb-1">{election.title}</h3>
                  <div className="flex items-center gap-4 text-sm text-slate-500">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      Ends Jun 15, 6:00 PM
                    </span>
                    <span>•</span>
                    <span>{election.candidates} Candidates</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  {election.voted ? (
                    <div className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-700 rounded-full text-sm font-bold border border-green-100">
                      <CheckCircle2 className="w-4 h-4" />
                      Voted
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 text-amber-700 rounded-full text-sm font-bold border border-amber-100">
                      <AlertCircle className="w-4 h-4" />
                      Pending
                    </div>
                  )}
                  
                  {election.voted ? (
                    <button disabled className="px-6 py-2 bg-slate-100 text-slate-400 rounded-xl font-bold text-sm cursor-not-allowed">
                      Cast Vote
                    </button>
                  ) : (
                    <Link 
                      href={`/vote/${election.id}`}
                      className="px-6 py-2 bg-blue-600 text-white rounded-xl font-bold text-sm hover:bg-blue-700 transition-all shadow-md hover:shadow-lg flex items-center gap-2"
                    >
                      Cast Vote
                      <ChevronRight className="w-4 h-4" />
                    </Link>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Past Elections */}
        <section>
          <h2 className="text-xl font-bold text-slate-800 mb-6">Recent History</h2>
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            {PAST_ELECTIONS.map((e, idx) => (
              <div key={e.id} className={`p-4 flex items-center justify-between ${idx !== 0 ? 'border-t border-slate-100' : ''}`}>
                <div>
                  <p className="font-bold text-slate-800">{e.title}</p>
                  <p className="text-sm text-slate-500">{e.date} • Winner: {e.winner}</p>
                </div>
                <Link href={`/results/${e.id}`} className="text-blue-600 text-sm font-bold hover:underline">
                  View Results
                </Link>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
